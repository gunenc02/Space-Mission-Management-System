create definer = root@localhost trigger check_agency_mail_insert
    before insert
    on agency
    for each row
BEGIN DECLARE user_mail VARCHAR(255); SELECT user.user_mail INTO user_mail FROM user WHERE user_id = NEW.agency_id; IF (user_mail <> NEW.agency_mail) THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Check failed. There exists no such agency mail in the user table'; END IF; END;

