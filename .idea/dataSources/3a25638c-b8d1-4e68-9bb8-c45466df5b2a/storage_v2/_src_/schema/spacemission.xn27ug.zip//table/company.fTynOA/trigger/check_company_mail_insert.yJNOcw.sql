create definer = root@localhost trigger check_company_mail_insert
    before insert
    on company
    for each row
BEGIN DECLARE company_mail VARCHAR(255); SELECT company.company_mail INTO company_mail FROM company WHERE company_id = NEW.company_id; IF(company_mail <> NEW.company_mail) THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Check failed. There exists no such company mail in the user table'; END IF; END;

