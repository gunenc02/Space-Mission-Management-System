create definer = root@localhost trigger check_expert_mail_insert
    before insert
    on expert
    for each row
BEGIN DECLARE expert_mail VARCHAR(255); SELECT expert.expert_mail INTO expert_mail FROM expert WHERE expert_id = NEW.expert_id; IF(expert_mail <> NEW.expert_mail) THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Check failed. There exists no such expert mail in the user table'; END IF; END;

