create definer = root@localhost trigger release_astronaut
    after update
    on space_mission
    for each row
BEGIN IF (OLD.perform_status = 'pending' AND NEW.perform_status = 'performed') THEN UPDATE astronaut SET on_duty = FALSE WHERE astronaut.astronaut_id IN (SELECT astronaut_id FROM mission_astronaut_recordings WHERE mission_id = OLD.mission_id); END IF; END;

