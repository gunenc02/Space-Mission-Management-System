create definer = root@localhost trigger delete_experts
    before delete
    on company
    for each row
BEGIN DELETE FROM expert WHERE expert_company = OLD.company_id; END;

