create definer = root@localhost view platform_availability as
select `spacemission`.`platform`.`platform_id`                                                          AS `platform_id`,
       (select count(0)
        from `spacemission`.`space_mission`
        where (`spacemission`.`space_mission`.`platform_id` = `spacemission`.`platform`.`platform_id`)) AS `Name_exp_2`
from `spacemission`.`platform`;

