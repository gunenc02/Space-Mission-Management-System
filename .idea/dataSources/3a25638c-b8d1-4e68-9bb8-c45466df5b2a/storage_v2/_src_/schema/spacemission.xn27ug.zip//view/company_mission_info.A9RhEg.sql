create definer = root@localhost view company_mission_info as
select `comp`.`company_name` AS `company_name`,
       `comp`.`worker_count` AS `worker_count`,
       `miss`.`mission_name` AS `mission_name`,
       `miss`.`objective`    AS `objective`,
       `a`.`astronaut_name`  AS `astronaut_name`
from (((`spacemission`.`company` `comp` join `spacemission`.`space_mission` `miss`
        on ((`comp`.`company_id` = `miss`.`creator_id`))) left join `spacemission`.`mission_astronaut_recordings` `mar`
       on ((`miss`.`mission_id` = `mar`.`mission_id`))) join `spacemission`.`astronaut` `a`
      on ((`mar`.`astronaut_id` = `a`.`astronaut_id`)));

